var classwidget_1_1_custom_chart_view =
[
    [ "paintEvent", "classwidget_1_1_custom_chart_view.html#aa70d25625a278124b97339ce32ec44c4", null ]
];