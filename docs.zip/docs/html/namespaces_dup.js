var namespaces_dup =
[
    [ "ui_form", "namespaceui__form.html", "namespaceui__form" ],
    [ "widget", "namespacewidget.html", "namespacewidget" ]
];