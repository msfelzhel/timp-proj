var searchData=
[
  ['retranslateui_0',['retranslateUi',['../classui__form_1_1_ui___widget.html#a4e920c4f237dbb051306e71bec2742e3',1,'ui_form::Ui_Widget']]]
];
