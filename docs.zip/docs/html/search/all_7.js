var searchData=
[
  ['init_5fui_0',['init_ui',['../classwidget_1_1_function_screen.html#a9a9a0ab76948c2edc9dcdbaf70ab27be',1,'widget::FunctionScreen']]]
];
