var searchData=
[
  ['b_0',['b',['../classwidget_1_1_function_screen.html#ac6061d77c6303e818736e31a02daacf8',1,'widget::FunctionScreen']]]
];
