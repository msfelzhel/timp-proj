var searchData=
[
  ['widget_0',['widget',['../namespacewidget.html',1,'']]],
  ['widget_2epy_1',['widget.py',['../widget_8py.html',1,'']]],
  ['window_2',['window',['../namespacewidget.html#a0e3acaf2faedcba60522fcc047ba6290',1,'widget']]]
];
