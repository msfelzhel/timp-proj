var searchData=
[
  ['window_0',['window',['../namespacewidget.html#a0e3acaf2faedcba60522fcc047ba6290',1,'widget']]]
];
