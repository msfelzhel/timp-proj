var searchData=
[
  ['function_5fscreen_0',['function_screen',['../classwidget_1_1_main_window.html#abdd671d32f69a8f72b3fb933f34106c2',1,'widget::MainWindow']]]
];
