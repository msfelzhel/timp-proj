var searchData=
[
  ['update_5fall_0',['update_all',['../classwidget_1_1_function_screen.html#a948bfea7cecdb1f311ae3f2b567b20b7',1,'widget::FunctionScreen']]],
  ['update_5fplot_1',['update_plot',['../classwidget_1_1_function_screen.html#a0c989f1a3d6cb6979947786fb7bd6ee0',1,'widget::FunctionScreen']]],
  ['update_5ftable_2',['update_table',['../classwidget_1_1_function_screen.html#a55ce60899204ce87774d2cf2ffd598ae',1,'widget::FunctionScreen']]]
];
