var searchData=
[
  ['paintevent_0',['paintEvent',['../classwidget_1_1_custom_chart_view.html#aa70d25625a278124b97339ce32ec44c4',1,'widget::CustomChartView']]],
  ['parent_5fapp_1',['parent_app',['../classwidget_1_1_auth_screen.html#af17357cd0f6afae0eab524af2bc6ca5b',1,'widget::AuthScreen']]],
  ['port_2',['port',['../classwidget_1_1_tcp_client.html#acc0235418f73f6fb11a09fd9b4bcc595',1,'widget::TcpClient']]]
];
