var searchData=
[
  ['send_0',['send',['../classwidget_1_1_tcp_client.html#a175fe1306b66829bd5878fe816dd9d75',1,'widget::TcpClient']]],
  ['setupui_1',['setupUi',['../classui__form_1_1_ui___widget.html#a0ea2bf14ed3c224dea5652be14838e6f',1,'ui_form::Ui_Widget']]],
  ['show_5fauth_5fscreen_2',['show_auth_screen',['../classwidget_1_1_main_window.html#a752fea38eec6124da5d51c4b5be391dd',1,'widget::MainWindow']]],
  ['show_5ffunction_5fscreen_3',['show_function_screen',['../classwidget_1_1_main_window.html#a57fb3fe0583eccd755028a6680344d62',1,'widget::MainWindow']]]
];
