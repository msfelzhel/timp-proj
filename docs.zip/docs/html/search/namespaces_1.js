var searchData=
[
  ['widget_0',['widget',['../namespacewidget.html',1,'']]]
];
