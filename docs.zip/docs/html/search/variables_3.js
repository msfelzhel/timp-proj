var searchData=
[
  ['c_0',['c',['../classwidget_1_1_function_screen.html#a5bca8e7ecc456d6a768e9f575eae8da2',1,'widget::FunctionScreen']]],
  ['client_1',['client',['../classwidget_1_1_function_screen.html#a75c054e5b1302785444cd94276e9ee71',1,'widget.FunctionScreen.client'],['../classwidget_1_1_auth_screen.html#a830c25d071242a336a953d5dd1ec7a69',1,'widget.AuthScreen.client']]]
];
