var searchData=
[
  ['_5f_5finit_5f_5f_0',['__init__',['../classwidget_1_1_tcp_client.html#a013aea8603f6f8739837684030260336',1,'widget.TcpClient.__init__()'],['../classwidget_1_1_function_screen.html#a69ba96dbc7bd8c65fe89d5a586424c44',1,'widget.FunctionScreen.__init__()'],['../classwidget_1_1_title_screen.html#a1648b563814acefc6f5d8b45c1f96858',1,'widget.TitleScreen.__init__()'],['../classwidget_1_1_auth_screen.html#a324a612e7d599bb976c500d50a2149f9',1,'widget.AuthScreen.__init__()'],['../classwidget_1_1_main_window.html#a141def6c92d658e83de68653e6bccdbd',1,'widget.MainWindow.__init__()']]],
  ['_5fadd_5fsegment_1',['_add_segment',['../classwidget_1_1_function_screen.html#addbefc13e493d3875a71ebdc46d35a8d',1,'widget::FunctionScreen']]],
  ['_5fclear_5fdynamic_5fseries_2',['_clear_dynamic_series',['../classwidget_1_1_function_screen.html#a8721c52c1dcfac628a22eb6d2486e839',1,'widget::FunctionScreen']]],
  ['_5fdynamic_5fseries_3',['_dynamic_series',['../classwidget_1_1_function_screen.html#adf62551285ca2e45a90e0e593c8909da',1,'widget::FunctionScreen']]],
  ['_5frequest_5fpoints_4',['_request_points',['../classwidget_1_1_function_screen.html#a0e0d276791a355933a0e8b9cb9a6043b',1,'widget::FunctionScreen']]]
];
