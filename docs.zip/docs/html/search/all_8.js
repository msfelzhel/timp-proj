var searchData=
[
  ['mainwindow_0',['MainWindow',['../classwidget_1_1_main_window.html',1,'widget']]]
];
