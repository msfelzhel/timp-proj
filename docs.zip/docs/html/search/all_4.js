var searchData=
[
  ['do_5flogin_0',['do_login',['../classwidget_1_1_auth_screen.html#a1c1cf38902a0a7585b04c7de40830fec',1,'widget::AuthScreen']]],
  ['do_5fregister_1',['do_register',['../classwidget_1_1_auth_screen.html#a9fec085e656579f19cd0b96d9de2b409',1,'widget::AuthScreen']]]
];
