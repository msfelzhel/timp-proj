var searchData=
[
  ['_5fdynamic_5fseries_0',['_dynamic_series',['../classwidget_1_1_function_screen.html#adf62551285ca2e45a90e0e593c8909da',1,'widget::FunctionScreen']]]
];
