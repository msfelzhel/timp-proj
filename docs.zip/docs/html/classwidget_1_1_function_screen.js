var classwidget_1_1_function_screen =
[
    [ "__init__", "classwidget_1_1_function_screen.html#a69ba96dbc7bd8c65fe89d5a586424c44", null ],
    [ "_add_segment", "classwidget_1_1_function_screen.html#addbefc13e493d3875a71ebdc46d35a8d", null ],
    [ "_clear_dynamic_series", "classwidget_1_1_function_screen.html#a8721c52c1dcfac628a22eb6d2486e839", null ],
    [ "_request_points", "classwidget_1_1_function_screen.html#a0e0d276791a355933a0e8b9cb9a6043b", null ],
    [ "init_ui", "classwidget_1_1_function_screen.html#a9a9a0ab76948c2edc9dcdbaf70ab27be", null ],
    [ "update_all", "classwidget_1_1_function_screen.html#a948bfea7cecdb1f311ae3f2b567b20b7", null ],
    [ "update_plot", "classwidget_1_1_function_screen.html#a0c989f1a3d6cb6979947786fb7bd6ee0", null ],
    [ "update_table", "classwidget_1_1_function_screen.html#a55ce60899204ce87774d2cf2ffd598ae", null ],
    [ "_dynamic_series", "classwidget_1_1_function_screen.html#adf62551285ca2e45a90e0e593c8909da", null ],
    [ "a", "classwidget_1_1_function_screen.html#ae6c9ef013f255d959df382b1fcb07570", null ],
    [ "axis_x", "classwidget_1_1_function_screen.html#af55f7f16788d302115be555202d05dbc", null ],
    [ "axis_y", "classwidget_1_1_function_screen.html#aca8ddd11c3ed0bffdbfce6dfa18eb140", null ],
    [ "b", "classwidget_1_1_function_screen.html#ac6061d77c6303e818736e31a02daacf8", null ],
    [ "c", "classwidget_1_1_function_screen.html#a5bca8e7ecc456d6a768e9f575eae8da2", null ],
    [ "client", "classwidget_1_1_function_screen.html#a75c054e5b1302785444cd94276e9ee71", null ]
];