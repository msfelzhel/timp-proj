var classwidget_1_1_auth_screen =
[
    [ "__init__", "classwidget_1_1_auth_screen.html#a324a612e7d599bb976c500d50a2149f9", null ],
    [ "do_login", "classwidget_1_1_auth_screen.html#a1c1cf38902a0a7585b04c7de40830fec", null ],
    [ "do_register", "classwidget_1_1_auth_screen.html#a9fec085e656579f19cd0b96d9de2b409", null ],
    [ "client", "classwidget_1_1_auth_screen.html#a830c25d071242a336a953d5dd1ec7a69", null ],
    [ "parent_app", "classwidget_1_1_auth_screen.html#af17357cd0f6afae0eab524af2bc6ca5b", null ]
];