var annotated_dup =
[
    [ "ui_form", "namespaceui__form.html", [
      [ "Ui_Widget", "classui__form_1_1_ui___widget.html", "classui__form_1_1_ui___widget" ]
    ] ],
    [ "widget", "namespacewidget.html", [
      [ "TcpClient", "classwidget_1_1_tcp_client.html", "classwidget_1_1_tcp_client" ],
      [ "CustomChartView", "classwidget_1_1_custom_chart_view.html", "classwidget_1_1_custom_chart_view" ],
      [ "FunctionScreen", "classwidget_1_1_function_screen.html", "classwidget_1_1_function_screen" ],
      [ "TitleScreen", "classwidget_1_1_title_screen.html", "classwidget_1_1_title_screen" ],
      [ "AuthScreen", "classwidget_1_1_auth_screen.html", "classwidget_1_1_auth_screen" ],
      [ "MainWindow", "classwidget_1_1_main_window.html", "classwidget_1_1_main_window" ]
    ] ]
];