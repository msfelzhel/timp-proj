var classwidget_1_1_tcp_client =
[
    [ "__init__", "classwidget_1_1_tcp_client.html#a013aea8603f6f8739837684030260336", null ],
    [ "send", "classwidget_1_1_tcp_client.html#a175fe1306b66829bd5878fe816dd9d75", null ],
    [ "host", "classwidget_1_1_tcp_client.html#abed8a6ae8b3a4cee738831f298dddf62", null ],
    [ "port", "classwidget_1_1_tcp_client.html#acc0235418f73f6fb11a09fd9b4bcc595", null ]
];