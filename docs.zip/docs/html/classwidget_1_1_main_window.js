var classwidget_1_1_main_window =
[
    [ "__init__", "classwidget_1_1_main_window.html#a141def6c92d658e83de68653e6bccdbd", null ],
    [ "show_auth_screen", "classwidget_1_1_main_window.html#a752fea38eec6124da5d51c4b5be391dd", null ],
    [ "show_function_screen", "classwidget_1_1_main_window.html#a57fb3fe0583eccd755028a6680344d62", null ],
    [ "auth_screen", "classwidget_1_1_main_window.html#a7c6a6e39297aaae2f522069a70b43347", null ],
    [ "function_screen", "classwidget_1_1_main_window.html#abdd671d32f69a8f72b3fb933f34106c2", null ]
];