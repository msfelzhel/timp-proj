var files_dup =
[
    [ "ui_form.py", "ui__form_8py.html", "ui__form_8py" ],
    [ "widget.py", "widget_8py.html", "widget_8py" ]
];