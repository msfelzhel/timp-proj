var classui__form_1_1_ui___widget =
[
    [ "retranslateUi", "classui__form_1_1_ui___widget.html#a4e920c4f237dbb051306e71bec2742e3", null ],
    [ "setupUi", "classui__form_1_1_ui___widget.html#a0ea2bf14ed3c224dea5652be14838e6f", null ]
];