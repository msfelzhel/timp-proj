var classwidget_1_1_title_screen =
[
    [ "__init__", "classwidget_1_1_title_screen.html#a1648b563814acefc6f5d8b45c1f96858", null ]
];