var hierarchy =
[
    [ "object", null, [
      [ "ui_form.Ui_Widget", "classui__form_1_1_ui___widget.html", null ]
    ] ],
    [ "QChartView", null, [
      [ "widget.CustomChartView", "classwidget_1_1_custom_chart_view.html", null ]
    ] ],
    [ "QMainWindow", null, [
      [ "widget.MainWindow", "classwidget_1_1_main_window.html", null ]
    ] ],
    [ "QWidget", null, [
      [ "widget.AuthScreen", "classwidget_1_1_auth_screen.html", null ],
      [ "widget.FunctionScreen", "classwidget_1_1_function_screen.html", null ],
      [ "widget.TitleScreen", "classwidget_1_1_title_screen.html", null ]
    ] ],
    [ "widget.TcpClient", "classwidget_1_1_tcp_client.html", null ]
];