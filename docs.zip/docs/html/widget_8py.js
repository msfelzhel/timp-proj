var widget_8py =
[
    [ "widget.TcpClient", "classwidget_1_1_tcp_client.html", "classwidget_1_1_tcp_client" ],
    [ "widget.CustomChartView", "classwidget_1_1_custom_chart_view.html", "classwidget_1_1_custom_chart_view" ],
    [ "widget.FunctionScreen", "classwidget_1_1_function_screen.html", "classwidget_1_1_function_screen" ],
    [ "widget.TitleScreen", "classwidget_1_1_title_screen.html", "classwidget_1_1_title_screen" ],
    [ "widget.AuthScreen", "classwidget_1_1_auth_screen.html", "classwidget_1_1_auth_screen" ],
    [ "widget.MainWindow", "classwidget_1_1_main_window.html", "classwidget_1_1_main_window" ],
    [ "widget.app", "namespacewidget.html#acd5e8198166b2e7593187163f2d8e9d7", null ],
    [ "widget.window", "namespacewidget.html#a0e3acaf2faedcba60522fcc047ba6290", null ]
];