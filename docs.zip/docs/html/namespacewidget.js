var namespacewidget =
[
    [ "TcpClient", "classwidget_1_1_tcp_client.html", "classwidget_1_1_tcp_client" ],
    [ "CustomChartView", "classwidget_1_1_custom_chart_view.html", "classwidget_1_1_custom_chart_view" ],
    [ "FunctionScreen", "classwidget_1_1_function_screen.html", "classwidget_1_1_function_screen" ],
    [ "TitleScreen", "classwidget_1_1_title_screen.html", "classwidget_1_1_title_screen" ],
    [ "AuthScreen", "classwidget_1_1_auth_screen.html", "classwidget_1_1_auth_screen" ],
    [ "MainWindow", "classwidget_1_1_main_window.html", "classwidget_1_1_main_window" ],
    [ "app", "namespacewidget.html#acd5e8198166b2e7593187163f2d8e9d7", null ],
    [ "window", "namespacewidget.html#a0e3acaf2faedcba60522fcc047ba6290", null ]
];